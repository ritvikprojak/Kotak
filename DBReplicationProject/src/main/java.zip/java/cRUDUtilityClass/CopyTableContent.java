package cRUDUtilityClass;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ResourceBundle;

import cripUtilityPackage.AES;
//import cripUtilityPackage.CripUtility;
import dDReplication.MasterSlaveDBreplication;

public class CopyTableContent {
	
	static ResourceBundle rBProps = MasterSlaveDBreplication.rBProps;

	//only This Method is Used
	public void copyHRMS2HRMS_HRRM(Connection sourceCon, Connection targetCon) throws SQLException {

		//System.out.println("Inside copyHRMS2HRMS_HRRM");
		try {
			
			// 60 Question Marks"?"
			PreparedStatement targetInsertSQL = targetCon
					.prepareStatement(
					
					"INSERT INTO "+rBProps.getString("hRMS_HRRMTableName")
							+ " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"

					);
			// Perform select / open Cursor
			Statement selectViewStm = sourceCon.createStatement();
			ResultSet sourceResultSet = selectViewStm.executeQuery("SELECT * FROM "+rBProps.getString("hRMSTableName"));
			
			int currentBatchSize = 0;
			int mAXBATCHSIZE = 1000;
			while ( sourceResultSet.next()) {
				// Set into INSERT the values we SELECTED
				targetInsertSQL.setString(1, ((ResultSet) sourceResultSet).getString("EMPLOYEE_NUMBER"));
				targetInsertSQL.setInt(2, sourceResultSet.getInt("ORACLE_EMPLOYEE_NUMBER"));
				targetInsertSQL.setString(3, sourceResultSet.getString("COMPANY"));
				targetInsertSQL.setString(4, sourceResultSet.getString("PERSON_ID"));
				targetInsertSQL.setString(5, sourceResultSet.getString("ATTRIBUTE3"));
				targetInsertSQL.setString(6, sourceResultSet.getString("PREFIX"));
				targetInsertSQL.setString(7, sourceResultSet.getString("FIRST_NAME"));
				targetInsertSQL.setString(8, sourceResultSet.getString("MIDDLE_NAMES"));
				targetInsertSQL.setString(9, sourceResultSet.getString("LAST_NAME"));
				targetInsertSQL.setString(10, sourceResultSet.getString("LAST_NAME"));
				targetInsertSQL.setString(11, sourceResultSet.getString("GENDER"));
				targetInsertSQL.setDate(12, sourceResultSet.getDate("DOB"));
				// MARITAL_STATUS is actually CHAR(10) BYTE
				targetInsertSQL.setString(13, sourceResultSet.getString("MARITAL_STATUS"));
				targetInsertSQL.setString(14, sourceResultSet.getString("PADDRESS1"));
				targetInsertSQL.setString(15, sourceResultSet.getString("PADDRESS2"));
				targetInsertSQL.setString(16, sourceResultSet.getString("PADDRESS3"));
				targetInsertSQL.setString(17, sourceResultSet.getString("PCITY"));
				// PPIN is actually a CHAR(20) BYTE)
				targetInsertSQL.setString(18, sourceResultSet.getString("PPIN"));
				targetInsertSQL.setString(19, sourceResultSet.getString("TADDRESS1"));
				targetInsertSQL.setString(20, sourceResultSet.getString("TADDRESS2"));
				targetInsertSQL.setString(21, sourceResultSet.getString("TADDRESS3"));
				targetInsertSQL.setString(22, sourceResultSet.getString("TCITY"));
				// TPIN is actually a CHAR(6) BYTE)
				targetInsertSQL.setString(23, sourceResultSet.getString("TPIN"));
				targetInsertSQL.setString(24, sourceResultSet.getString("SUPERVISOR_EMP_NO"));
				targetInsertSQL.setString(25, sourceResultSet.getString("SUP_COMPANY"));
				targetInsertSQL.setDate(26, sourceResultSet.getDate("DOJ"));
				targetInsertSQL.setString(27, sourceResultSet.getString("FATHER_HUSBAND_NAME"));
				targetInsertSQL.setString(28, sourceResultSet.getString("DIVISION"));
				targetInsertSQL.setString(29, sourceResultSet.getString("FUNCTION"));
				targetInsertSQL.setInt(30, sourceResultSet.getInt("FUNCTION_ID"));
				targetInsertSQL.setInt(31, sourceResultSet.getInt("DESIGNATION_ID"));
				// CHAR(10 BYTE)
				targetInsertSQL.setString(32, sourceResultSet.getString("PAYROLL_ID"));
				targetInsertSQL.setString(33, sourceResultSet.getString("DESIGNATION_LABEL_ID"));
				targetInsertSQL.setString(34, sourceResultSet.getString("ROLE"));
				targetInsertSQL.setString(35, sourceResultSet.getString("LOC_CODE"));
				targetInsertSQL.setString(36, sourceResultSet.getString("LOC_CODE"));
				targetInsertSQL.setDate(37, sourceResultSet.getDate("DATE_EMPLOYEE_DATA_VERIFIED"));
				targetInsertSQL.setString(38, sourceResultSet.getString("LOB_CODE"));
				targetInsertSQL.setString(39, sourceResultSet.getString("LOB"));
				targetInsertSQL.setString(40, sourceResultSet.getString("CC_CODE"));
				targetInsertSQL.setString(41, sourceResultSet.getString("CC_NAME"));
				targetInsertSQL.setString(42, sourceResultSet.getString("CC_NAME"));
				targetInsertSQL.setString(43, sourceResultSet.getString("DOMAIN_LOGIN_ID"));
				targetInsertSQL.setDate(44, sourceResultSet.getDate("LAST_WORKING_DATE"));
				targetInsertSQL.setString(45, sourceResultSet.getString("RM_NAME"));
				targetInsertSQL.setString(46, sourceResultSet.getString("RM_NAME"));
				targetInsertSQL.setString(47, sourceResultSet.getString("RM_NAME"));
				targetInsertSQL.setString(48, sourceResultSet.getString("KPO_CODE"));
				targetInsertSQL.setString(49, sourceResultSet.getString("SUPERVISOR_NAME"));
				// Char(13 BYTE)
				targetInsertSQL.setString(50, sourceResultSet.getString("MOBILE_NUMBER"));
				targetInsertSQL.setDate(51, sourceResultSet.getDate("ASSIGNMENT_CHANGE_DATE"));
				targetInsertSQL.setString(52, sourceResultSet.getString("LOC_CODE_NEW"));
				targetInsertSQL.setString(53, sourceResultSet.getString("LOC_CODE_NEW"));
				targetInsertSQL.setString(54, sourceResultSet.getString("LOC_CODE_NEW"));
				targetInsertSQL.setString(55, sourceResultSet.getString("LOC_CODE_NEW"));
				// CHAR(10 BYTE)
				targetInsertSQL.setString(56, sourceResultSet.getString("PAN_NO"));
				targetInsertSQL.setDate(57, sourceResultSet.getDate("DOJ_KOTAK_GROUP"));
				targetInsertSQL.setString(58, sourceResultSet.getString("RM_EMAIL"));
				targetInsertSQL.setString(59, sourceResultSet.getString("GRADE_ID"));
				targetInsertSQL.setNull(60, Types.VARCHAR);
				targetInsertSQL.addBatch();
				if (++currentBatchSize % mAXBATCHSIZE == 0) {
					targetInsertSQL.executeBatch();
					//targetCon.commit();
				}// if Ends
			}// While Ends
			if (++currentBatchSize % mAXBATCHSIZE != 0) {
				targetInsertSQL.executeBatch();
				//targetCon.commit();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}// method ends

	// method not used at Application Level
	public void loadDriver() throws ClassNotFoundException {
		Class.forName("oracle.jdbc.OracleDriver");
		System.out.println("Loaded the JDBC driver for: ORACLE");
		
	}//loadDriver
	// method not used at Application Level
	public Connection loadConnection(final String env, final ResourceBundle rBProps) throws SQLException,ClassNotFoundException {
		String url=null;
		String user=null;
		String password=null;
		Connection con = null;
		System.out.println("ORL Server Env loadConnection STARTs");
		//ORADatabase.getSSLAccess();
		// pre-requsites for loading the Connections
		final String urlPrefix = "jdbc:oracle:thin:@";
		
		if(env == "STG"){
			//jdbc:oracle:thin:@ // 192.168.1.18:1521/XEPDB1
			
			String ipaddress = "//"+rBProps.getString("STG_ORA_URI")+"/"+rBProps.getString("STG_ORA_DBNAME") ;  // get databaseName & ip_port from config.properties
			url = urlPrefix + ipaddress;
			System.out.println("ORA URL : " + url);
			user = rBProps.getString("STG_ORA_USERID");
			password =  AES.decrypt(rBProps.getString("STG_ORA_PASSWORD"));
			//password = rBProps.getString("STG_ORA_PASSWORD");
			System.out.println("url :"+url+"	|user :"+user+"	|password : "+password);
			
		}
		else if(env == "SERVER"){
			
			String ipaddress = "//"+rBProps.getString("ORA_URI")+"/"+rBProps.getString("ORA_DBNAME") ;  // get databaseName & ip_port from config.properties
			url = urlPrefix + ipaddress;
			System.out.println("ORA URL : " + url); // get databaseName & ip_port from config.properties
			user = rBProps.getString("ORA_USERID");
			password =  AES.decrypt(rBProps.getString("ORA_PASSWORD"));
			//password = rBProps.getString("ORA_PASSWORD");
		}
												
		try {
			con = DriverManager.getConnection(url, user, password);
			System.out.println("Printing Connection Object for ORA : " + con);
			System.out.println("ORA dataBase Now Accessed via user : " + user);
			System.out.println("Auto-commit is : "+con.getAutoCommit() );
		} finally {/*log.info( "Logging from finally block of : "+SQLDatabase.class.getName() )*/ ;}
		System.out.println("## loadConnection ENDs, Returning Connection Object ##");
		return con;
	}//loadConnection
	
	// Main not used at Application level
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CopyTableContent cmb = new CopyTableContent();
		try {
			cmb.loadDriver();
			Connection conServer = cmb.loadConnection("SERVER", rBProps);
			cmb.copyHRMS2HRMS_HRRM( cmb.loadConnection("STG", rBProps), conServer );
			conServer.commit();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}





/* Refer this if Selct SQL Needs the Colounm from HRMS
 * 							+" ( "
							+ "EMPLOYEE_NUMBER,"
							+ "ORACLE_EMPLOYEE_NUMBER,"
							+ "COMPANY,"
							+ "PERSON_ID,"
							+ "ATTRIBUTE3,"
							+ "PREFIX,"
							+ "FIRST_NAME,"
							+ "MIDDLE_NAMES,"
							+ "LAST_NAME,"
							+ "EMAIL_ADDRESS,"
							+ "GENDER,"
							+ "DOB,"
							+ "MARITAL_STATUS,"
							+ "PADDRESS1,"
							+ "PADDRESS2,"
							+ "PADDRESS3,"
							+ "PCITY,"
							+ "PPIN,"
							+ "TADDRESS1,"
							+ "TADDRESS2,"
							+ "TADDRESS3,"
							+ "TCITY,"
							+ "TPIN,"
							+ "SUPERVISOR_EMP_NO,"
							+ "SUP_COMPANY,"
							+ "DOJ,"
							+ "FATHER_HUSBAND_NAME,"
							+ "DIVISION,"
							+ "FUNCTION,"
							+ "FUNCTION_ID,"
							+ "DESIGNATION_ID,"
							+ "PAYROLL_ID,"
							+ "DESIGNATION_LABEL_ID,"
							+ "ROLE,"
							+ "LOC_CODE,"
							+ "LOCATION_NAME,"
							+ "DATE_EMPLOYEE_DATA_VERIFIED,"
							+ "LOB_CODE,"
							+ "LOB,"
							+ "CC_CODE,"
							+ "CC_NAME,"
							+ "CATEGORY,"
							+ "DOMAIN_LOGIN_ID,"
							+ "LAST_WORKING_DATE,"
							+ "RM_NAME,"
							+ "SUPERVISOR_NO,"
							+ "SOURCE,"
							+ "KPO_CODE,"
							+ "SUPERVISOR_NAME,"
							+ "MOBILE_NUMBER,"
							+ "ASSIGNMENT_CHANGE_DATE,"
							+ "LOC_CODE_NEW,"
							+ "ING_EMP_TYPE,"
							+ "SEGMENT,"
							+ "ROLE_ID,"
							+ "PAN_NO,"
							+ "DOJ_KOTAK_GROUP,"
							+ "RM_EMAIL,"
							+ "GRADE_ID"
							+" ) "
 */


