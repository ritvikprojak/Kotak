package activeDirectory;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.Iterator;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;

import javax.naming.ldap.LdapContext;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import dDReplication.MasterSlaveDBreplication;


public class UpmLdapEvents {
	
	static ResourceBundle rBProps = MasterSlaveDBreplication.rBProps;
	static String ldapURL = rBProps.getString("application.ldap.ldapURL");
	static String adminUser = rBProps.getString("application.rest.adminUser");
	static String ldapBindPassword = rBProps.getString("application.ldap.ldapBindPassword");
	//static String adminDN = rBProps.getString("application.ldap.ldapGroupSearchBase");
	static String trustStore = rBProps.getString("javax.net.ssl.trustStore");
	static String trustStorePassword = rBProps.getString("javax.net.ssl.trustStorePassword");
	String allowedGroup = rBProps.getString("allowedGroup");
 	String allowedAdminGroup = rBProps.getString("allowedAdminGroup");
	
	String userLoggedIn = null;
	
	
	public String GetUserGroupsByUserName(String commonDN,String userName){
		try {
			LdapContext ldapContext = LdapClient.GetLdapContext(ldapURL,adminUser,ldapBindPassword,trustStore,trustStorePassword);
			Map<String,String> userMap = LdapClient.GetUserGroupsByUserName(commonDN,userName, ldapContext);
			Set<String> keySet = userMap.keySet();
			Iterator<String> iter = keySet.iterator();
			while(iter.hasNext())
			{
				String key = (String)iter.next();
				//String value = userMap.get(key);
				//log.debug("key is "+key+" value is "+value);
				if(allowedGroup.contains(key))
				{
					userLoggedIn="Manager";
					//log.debug("Group Logged in is "+allowedGroup);
				}
				if(allowedAdminGroup.contains(key))
				{
					userLoggedIn="Admin";
					//log.debug("Group Logged in is "+allowedAdminGroup);
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userLoggedIn;
	}
	

	public void AddUserToGroup(String commonDN,String groupName, String userName){
		try {
			LdapContext ldapContext = LdapClient.GetLdapContext(ldapURL,adminUser,ldapBindPassword,trustStore,trustStorePassword);
			LdapClient.AddUserToGroup(commonDN,ldapContext, groupName, userName);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void RemoveUserFromGroup(String commonDN,String groupName, String userName){
		try {
			LdapContext ldapContext = LdapClient.GetLdapContext(ldapURL,adminUser,ldapBindPassword,trustStore,trustStorePassword);
			
			
			LdapClient.RemoveUserFromGroup(commonDN,ldapContext, groupName, userName);
			//System.out.println(providerUri+" "+ AdminUser+" "+ adminPwd+" "+ adminDN);
			//boolean response=LdapClient.RemoveUserFromGroup(ldapContext, groupName, userName);
			//System.out.println("Is "+userName+" removes from groupName : "+response );
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	public Map<String, String> GetAllUserGroups(String commonDN){
		Map<String, String> allGroups = null;
		try {
			LdapContext ldapContext = LdapClient.GetLdapContext(ldapURL,adminUser,ldapBindPassword,trustStore,trustStorePassword);
			allGroups = LdapClient.GetAllUserGroups(commonDN,ldapContext);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return allGroups;
	}
	
	public static Map<String, String> GetAllUsers(String commonDN){
		Map<String, String> allGroups = null;
		try {
			LdapContext ldapContext = LdapClient.GetLdapContext(ldapURL,adminUser,ldapBindPassword,trustStore,trustStorePassword);
			allGroups = LdapClient.GetAllUsers(commonDN, ldapContext);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return allGroups;
	}
	
	public void updateRole(String commonDN,String existingRole, String newRole,String userName)
	{
		existingRole = existingRole+"_Test";
		//existingRole = existingRole;
		//log.debug("existingRole is "+existingRole);
		newRole = newRole+"_Test";
		//newRole = newRole;
		//log.debug("newRole is "+newRole);
		/*Map<String, String> allGroups = GetAllUserGroups();
		Set keySet = allGroups.keySet();
		Iterator iter = keySet.iterator();
		String existingRoleGroup=null,newRoleGroup=null;
		while(iter.hasNext())
		{
			String key = (String) iter.next();
			if(key.equalsIgnoreCase(existingRole))
			{
				existingRoleGroup = allGroups.get(key);
				log.debug(" existingRoleGroup is "+existingRoleGroup);
			}
			else if(key.equalsIgnoreCase(newRole))
			{
				newRoleGroup = allGroups.get(key);
				log.debug(" newRoleGroup is "+newRoleGroup);
			}
			
			
		}
		if(null!=existingRoleGroup && null!=newRoleGroup)*/
		{
			RemoveUserFromGroup(commonDN,existingRole, userName);
			AddUserToGroup(commonDN,newRole, userName);
		}
		
	}
	
	
	@SuppressWarnings("unused")
	public String userAuthentication(String commonDN,String userName,String password) throws Exception
	{
		boolean flag = false,allowedFlag =false;
		String loggedInUser = null;
		String responseMessage = null;
		String userDistinguishedName = getUserDistinguishedName(commonDN,userName);
		UpmLdapEvents.getSSLAccess();
		
		try 
		{
			if(null!=userDistinguishedName)
			{
				
				int comaIndexOf = userDistinguishedName.indexOf(",");
				if(comaIndexOf!=-1)
				{
					String adUserName = userDistinguishedName.substring(0,comaIndexOf);
					//log.debug("UserDN is "+adUserName);
					adUserName = adUserName.split("=")[1];
					//log.debug("adUserName is "+adUserName);
					userDistinguishedName = userDistinguishedName.substring(++comaIndexOf);
					//log.debug("userDistinguishedName is "+userDistinguishedName);
					LdapContext ldapContext = LdapClient.GetLdapContext(ldapURL,adminUser,ldapBindPassword,trustStore,trustStorePassword);
					//log.debug("ldapContext obtained "+ldapContext);
					responseMessage = "User Logged in successfully";
					flag = true;
					userLoggedIn = GetUserGroupsByUserName(commonDN,userName);
					if(!allowedFlag)
						flag = false;
				}
			}			
			else
			{
				responseMessage = "User doesn't exists, please check username and password";
				flag = false;
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			
			/*throw e;*/
		}
		return userLoggedIn;
	}
	
	public static void  getSSLAccess(){
		 
		 //sec = true
		 
			 TrustManager[] trustAllCerts = new TrustManager[] {
				       new X509TrustManager() {
				          public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				            return null;
				          }

				          public void checkClientTrusted(X509Certificate[] certs, String authType) {  }

				          public void checkServerTrusted(X509Certificate[] certs, String authType) {  }

				       }
				    };

				    SSLContext sc;
					try {
						sc = SSLContext.getInstance("SSL");
						sc.init(null, trustAllCerts, new java.security.SecureRandom());
						  HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

						    // Create all-trusting host name verifier
						    HostnameVerifier allHostsValid = new HostnameVerifier() {
						        public boolean verify(String hostname, SSLSession session) {
						          return true;
						        }
						    };
						    // Install the all-trusting host verifier
						    HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
					} catch (NoSuchAlgorithmException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				    catch (KeyManagementException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				  
				    /*
				     * end of the fix
				     */
				    
		 
		 
		 
	}
	
	public String getUserDistinguishedName(String commonDN, String userName)
	{
		String userDistinguishedName = null;
		LdapContext ldapContext;
		try {
			ldapContext = LdapClient.GetLdapContext(ldapURL,adminUser,ldapBindPassword,trustStore,trustStorePassword);
			userDistinguishedName = LdapClient.GetUserDistinguishedName(commonDN,userName,ldapContext);
			//log.debug("userDistinguishedName is "+userDistinguishedName);
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return userDistinguishedName;
	}
	
	public String findUserByUserName(String commonDN, String userName)
	{
		String userDistinguishedName = null;
		LdapContext ldapContext;
		try {
			ldapContext = LdapClient.GetLdapContext(ldapURL,adminUser,ldapBindPassword,trustStore,trustStorePassword);
			userDistinguishedName = LdapClient.GetUserDistinguishedName(commonDN,userName,ldapContext);
			//log.debug("userDistinguishedName is "+userDistinguishedName);
			//System.out.println("userDistinguishedName is "+userDistinguishedName);
			userDistinguishedName  = userDistinguishedName.split(",")[0].split("=")[1];
			//log.debug("Name is "+userDistinguishedName);
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return userDistinguishedName;
	}
	public static void main(String a[]) throws Exception
	{
		String commonDN = "OU=fncm,DC=KGPUAT,DC=COM";
		UpmLdapEvents ldapEvents = new UpmLdapEvents();
		//ldapEvents.findUserByUserName("PF161852");
		//ldapEvents.findUserByUserName("PF164418");
		//ldapEvents.findUserByUserName("psmall");
		//ldapEvents.GetUserGroupsByUserName("aniket");
		//ldapEvents.userAuthentication("p8admin","Filenet8");
		//GetAllUsers();
		//ldapEvents.GetAllUserGroups();
		//ldapEvents.RemoveUserFromGroup("UPMadmin", "PF161852");
		ldapEvents.RemoveUserFromGroup(commonDN,"FN_HR_MODIFY","Anup");
		//ldapEvents.GetUserGroupsByUserName("p8admin");
		//ldapEvents.AddUserToGroup("AreaManager","PF161852");
		//GetUserGroupsByUserName("pf203860");
		//ldapEvents.GetUserGroupsByUserName("PF161852");
		
		
		try {
			//ldapEvents.userAuthentication("rlcmanager1","boc@123");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
